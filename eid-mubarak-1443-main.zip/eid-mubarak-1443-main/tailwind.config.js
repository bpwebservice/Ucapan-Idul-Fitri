module.exports = {
  content: ['index.html'],
  theme: {
    extend: {
      fontFamily: {
        almarai: ['Almarai'],
        poppins: ['Poppins'],
      },
    },
  },
  plugins: [],
};
